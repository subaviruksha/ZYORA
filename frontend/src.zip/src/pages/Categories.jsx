
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Categories.css";
import Footer from "../components/Footer";

function CategoryImage({ products, category }) {
  const [imageIndex, setImageIndex] = useState(0);

  const categoryProducts = products.filter(
    (item) =>
      item.category?.trim().toLowerCase() ===
        category.trim().toLowerCase() &&
      typeof item.image === "string" &&
      item.image.trim() !== ""
  );

  const getImageUrl = (image) => {
    if (!image) return "";

    const filename = image
      .trim()
      .split("/")
      .pop();

    return `/productimage/${encodeURIComponent(filename)}`;
  };

  if (imageIndex >= categoryProducts.length) {
    return (
      <div className="categoryplaceholder">
        No Image Available
      </div>
    );
  }

  const imageUrl = getImageUrl(
    categoryProducts[imageIndex].image
  );

  return (
    <img
      key={imageUrl}
      src={imageUrl}
      alt={category}
      onError={() => {
        console.log(
          "Image failed for",
          category,
          ":",
          imageUrl
        );

        setImageIndex((previous) => previous + 1);
      }}
    />
  );
}

function Categories() {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetch("https://zyora-backend-rhv6.onrender.com/api/products")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch products");
        }

        return response.json();
      })
      .then((data) => {
        setProducts(Array.isArray(data) ? data : []);
      })
      .catch((error) => {
        console.log("Error fetching products:", error);
      });
  }, []);

  const categories = [
    {
      name: "Mobiles",
      description: "Smartphones and accessories"
    },
    {
      name: "Laptops",
      description: "Laptops and computers"
    },
    {
      name: "Electronics",
      description: "Gadgets and electronic products"
    },
    {
      name: "Men's Fashion",
      description: "Clothing and accessories"
    },
    {
      name: "Women's Fashion",
      description: "Clothing and accessories"
    },
    {
      name: "Toys",
      description: "Fun and educational toys"
    },
    {
      name: "Home & Kitchen",
      description: "Home and kitchen essentials"
    },
    {
      name: "Stationery",
      description: "School and office essentials"
    },
    {
      name: "Sports & Fitness",
      description: "Fitness and workout essentials"
    },
    {
      name: "Beauty",
      description: "Beauty and personal care"
    }
  ];

  const filteredCategories = categories.filter(
    (category) =>
      category.name
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
  );

  return (
    <div className="categories-page">

      <div className="categories-header">
        <p>EXPLORE ZYORA</p>

        <h1>Shop by Category</h1>

        <span>
          Find everything you need in one place.
        </span>

        <div className="category-search">
          <input
            type="text"
            id="categorySearch"
            name="categorySearch"
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) =>
              setSearchTerm(e.target.value)
            }
          />

          <span>🔍</span>
        </div>
      </div>

      <div className="category-grid">

        {filteredCategories.map((category) => (
          <Link
            key={category.name}
            to={`/category/${encodeURIComponent(category.name)}`}
            className="categories-card"
          >

            <CategoryImage
              products={products}
              category={category.name}
            />

            <h3>
              {category.name === "Sports & Fitness"
                ? "Gym & Fitness"
                : category.name}
            </h3>

            <p>{category.description}</p>

          </Link>
        ))}

      </div>

      {filteredCategories.length === 0 && (
        <p className="no-category">
          No categories found.
        </p>
      )}

      <Footer />

    </div>
  );
}

export default Categories;
